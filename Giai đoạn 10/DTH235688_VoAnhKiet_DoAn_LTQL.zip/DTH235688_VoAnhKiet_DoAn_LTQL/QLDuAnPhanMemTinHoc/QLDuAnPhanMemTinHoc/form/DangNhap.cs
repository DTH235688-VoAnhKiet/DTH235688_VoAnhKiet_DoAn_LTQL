using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace QLDuAnPhanMemTinHoc.form
{
    public partial class DangNhap : Form
    {
        public DangNhap()
        {
            InitializeComponent();
            StylizeForm();
        }

        private void StylizeForm()
        {
            this.BackColor = System.Drawing.Color.FromArgb(245, 246, 250);
            foreach (Control c in this.Controls)
            {
                StylizeControls(c);
            }
        }

        private void StylizeControls(Control parent)
        {
            if (parent is System.Windows.Forms.Button btn)
            {
                btn.FlatStyle = FlatStyle.Flat;
                btn.FlatAppearance.BorderSize = 0;
                btn.Font = new System.Drawing.Font("Segoe UI", 10, System.Drawing.FontStyle.Bold);
                btn.ForeColor = System.Drawing.Color.White;

                string text = btn.Text.ToLower();
                if (text.Contains("đăng nhập")) btn.BackColor = System.Drawing.Color.FromArgb(52, 152, 219);
                else if (text.Contains("thoát") || text.Contains("hủy")) btn.BackColor = System.Drawing.Color.FromArgb(149, 165, 166);
                else btn.BackColor = System.Drawing.Color.FromArgb(41, 128, 185);
            }

            foreach (Control c in parent.Controls)
            {
                StylizeControls(c);
            }
        }

        private void btnDangNhap_Click(object sender, EventArgs e)
        {
            string user = txtTenDangNhap.Text.Trim();
            string pass = txtMatKhau.Text.Trim();

            if (string.IsNullOrWhiteSpace(user) || string.IsNullOrWhiteSpace(pass))
            {
                MessageBox.Show("Ný ơi, vui lòng nhập đầy đủ tên và mật khẩu nha!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string vaiTro = "";
            int idDangNhap = -1; // Biến này cực quan trọng để hứng ID nè

            // Tự lấy chuỗi kết nối từ App.config cho chuẩn mượt luôn ný, khỏi phải đổi tay
            string strKetNoi = System.Configuration.ConfigurationManager.ConnectionStrings["QLDAConnection"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(strKetNoi))
            {
                try
                {
                    conn.Open();
                    // Câu SQL thần thánh: Tìm nhân viên có User và Pass khớp với ný nhập
                    string sql = "SELECT ID, QuyenHan FROM NhanVien WHERE TenDangNhap = @User AND MatKhau = @Pass";
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@User", user);
                        cmd.Parameters.AddWithValue("@Pass", pass);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read()) // Nếu đọc được dữ liệu (tức là đăng nhập đúng)
                            {
                                idDangNhap = Convert.ToInt32(reader["ID"]); // Chộp ngay cái ID
                                vaiTro = reader["QuyenHan"].ToString();     // Chộp luôn cái quyền
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi kết nối CSDL: " + ex.Message);
                    return;
                }
            }

            // Xử lý sau khi check SQL xong
            if (idDangNhap != -1) // Có ID tức là đăng nhập thành công
            {
                MessageBox.Show($"Đăng nhập thành công! Chào {vaiTro} nha.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MessageBox.Show("Dữ liệu quyền ný đang cầm là: " + vaiTro);
                // MỞ MAINFORM VÀ NÉM CẢ "VAI TRÒ" LẪN "ID" QUA ĐÓ LUÔN
                MainForm fMain = new MainForm(vaiTro, idDangNhap);

                fMain.FormClosed += (s, args) => this.Close();
                fMain.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Sai tài khoản hoặc mật khẩu rồi ný!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtMatKhau.Clear();
                txtMatKhau.Focus();
            }
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult dt = MessageBox.Show("Ný chắc chắn muốn thoát chứ?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dt == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}

