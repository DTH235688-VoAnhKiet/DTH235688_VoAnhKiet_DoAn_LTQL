using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using QLDuAnPhanMemTinHoc.Data;

namespace QLDuAnPhanMemTinHoc.Data
{
    public static class DatabaseSeeder
    {
        public static void Seed()
        {
            using (var context = new QLDADbContext())
            {
                // 1. Kiểm tra nếu đã có nhân viên rồi thì thôi không seed nữa để tránh trùng
                if (context.NhanVien.Any(nv => nv.TenDangNhap == "admin"))
                {
                    return;
                }

                Console.WriteLine("Đang khởi tạo dữ liệu mẫu...");

                // 2. Tạo Khách hàng
                var khachHangs = new List<KhachHang>
                {
                    new KhachHang { MaKhachHang = "KH001", TenKhachHang = "Tập đoàn công nghệ Alpha", DienThoai = "0901234567", Email = "contact@alpha.com", DiaChi = "TP. Hồ Chí Minh" },
                    new KhachHang { MaKhachHang = "KH002", TenKhachHang = "Ngân hàng Thương mại Beta", DienThoai = "0987654321", Email = "info@beta.vn", DiaChi = "Hà Nội" },
                    new KhachHang { MaKhachHang = "KH003", TenKhachHang = "Công ty Xuất nhập khẩu Toàn Cầu", DienThoai = "0283844556", Email = "office@global.com", DiaChi = "Đà Nẵng" }
                };
                context.KhachHang.AddRange(khachHangs);
                context.SaveChanges();

                // 3. Tạo Nhân viên
                var nhanViens = new List<NhanVien>
                {
                    new NhanVien { MaNhanVien = "NV001", HoVaTen = "Nguyễn Văn Admin", DienThoai = "0911222333", Email = "admin@cty.com", TenDangNhap = "admin", MatKhau = "123", QuyenHan = true, ChucVu = "Quản trị viên", PhongBan = "Hệ thống", TrangThai = "Đang làm việc" },
                    new NhanVien { MaNhanVien = "NV002", HoVaTen = "Lê Thị Quản Lý", DienThoai = "0944555666", Email = "manager1@cty.com", TenDangNhap = "manager1", MatKhau = "123", QuyenHan = true, ChucVu = "Trưởng phòng", PhongBan = "Kỹ thuật", TrangThai = "Đang làm việc" },
                    new NhanVien { MaNhanVien = "NV003", HoVaTen = "Trần Văn Coder", DienThoai = "0977888999", Email = "dev1@cty.com", TenDangNhap = "dev1", MatKhau = "123", QuyenHan = false, ChucVu = "Lập trình viên", PhongBan = "Kỹ thuật", TrangThai = "Đang làm việc" },
                    new NhanVien { MaNhanVien = "NV004", HoVaTen = "Phạm Thị Tester", DienThoai = "0933444555", Email = "test1@cty.com", TenDangNhap = "test1", MatKhau = "123", QuyenHan = false, ChucVu = "Kiểm thử viên", PhongBan = "Kỹ thuật", TrangThai = "Đang làm việc" },
                    new NhanVien { MaNhanVien = "NV005", HoVaTen = "Hoàng Văn Dev", DienThoai = "0966777888", Email = "dev2@cty.com", TenDangNhap = "dev2", MatKhau = "123", QuyenHan = false, ChucVu = "Lập trình viên", PhongBan = "Kỹ thuật", TrangThai = "Đang làm việc" }
                };
                context.NhanVien.AddRange(nhanViens);
                context.SaveChanges();

                // 4. Tạo Dự án
                var duAn1 = new DuAn 
                { 
                    MaDuAn = "DA001", 
                    TenDuAn = "Hệ thống quản lý đào tạo E-Learning", 
                    KhachHangID = khachHangs[0].ID, 
                    QuanLyID = nhanViens[1].ID, 
                    NgayBatDau = DateTime.Now.AddMonths(-2), 
                    NgayKetThuc = DateTime.Now.AddMonths(4), 
                    TrangThai = "Đang triển khai", 
                    DoUuTien = "Cao", 
                    ChiPhi = 500000000 
                };
                var duAn2 = new DuAn 
                { 
                    MaDuAn = "DA002", 
                    TenDuAn = "Ứng dụng di động Fitness Tracking", 
                    KhachHangID = khachHangs[1].ID, 
                    QuanLyID = nhanViens[1].ID, 
                    NgayBatDau = DateTime.Now.AddMonths(-1), 
                    NgayKetThuc = DateTime.Now.AddMonths(5), 
                    TrangThai = "Đang triển khai", 
                    DoUuTien = "Trung bình", 
                    ChiPhi = 250000000 
                };
                context.DuAn.AddRange(duAn1, duAn2);
                context.SaveChanges();

                // 5. Tạo Công việc
                var congViecs = new List<CongViec>
                {
                    new CongViec { TenCongViec = "Thiết kế Database", DuAnID = duAn1.ID, NgayBatDau = DateTime.Now.AddMonths(-2), HanHoanThanh = DateTime.Now.AddMonths(-1), TrangThai = "Hoàn thành", DoUuTien = "Cao" },
                    new CongViec { TenCongViec = "Lập trình API Backend", DuAnID = duAn1.ID, NgayBatDau = DateTime.Now.AddMonths(-1), HanHoanThanh = DateTime.Now.AddDays(15), TrangThai = "Đang thực hiện", DoUuTien = "Cao" },
                    new CongViec { TenCongViec = "Thiết kế giao diện Mobile", DuAnID = duAn2.ID, NgayBatDau = DateTime.Now.AddMonths(-1), HanHoanThanh = DateTime.Now.AddDays(10), TrangThai = "Đang thực hiện", DoUuTien = "Trung bình" }
                };
                context.CongViec.AddRange(congViecs);
                context.SaveChanges();

                // 6. Phân công
                context.PhanCongCongViec.Add(new PhanCongCongViec { CongViecID = congViecs[1].ID, NhanVienID = nhanViens[2].ID });
                context.PhanCongCongViec.Add(new PhanCongCongViec { CongViecID = congViecs[2].ID, NhanVienID = nhanViens[4].ID });
                
                context.SaveChanges();
                Console.WriteLine("Đã bơm dữ liệu mẫu thành công!");
            }
        }

        public static void FixOldData()
        {
            using (var context = new QLDADbContext())
            {
                // Tạo bảng TienDo nếu chưa có để Cập nhật tiến độ không bị lỗi (Invalid object name 'TienDo')
                context.Database.ExecuteSqlRaw(@"
                    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='TienDo' and xtype='U')
                    BEGIN
                        CREATE TABLE TienDo (
                            ID INT IDENTITY(1,1) PRIMARY KEY,
                            CongViecID INT FOREIGN KEY REFERENCES CongViec(ID) ON DELETE CASCADE,
                            PhanTram INT,
                            NgayCapNhat DATETIME
                        )
                    END
                ");

                // Thay vì chỉ sửa thằng trống, ta đánh số lại TOÀN BỘ cho đẹp!
                
                // 1. Nhân viên
                var allNv = context.NhanVien.OrderBy(x => x.ID).ToList();
                int nvCounter = 1;
                foreach(var nv in allNv)
                {
                    nv.MaNhanVien = "NV" + nvCounter.ToString("D3");
                    nvCounter++;
                }

                // 2. Dự án
                var allDa = context.DuAn.OrderBy(x => x.ID).ToList();
                int daCounter = 1;
                foreach(var da in allDa)
                {
                    da.MaDuAn = "DA" + daCounter.ToString("D3");
                    daCounter++;
                }

                context.SaveChanges();
            }
        }
    }
}
